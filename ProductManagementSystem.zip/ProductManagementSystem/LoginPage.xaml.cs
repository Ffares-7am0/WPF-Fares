﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace ProductManagementSystem
{
    public partial class LoginPage : Window
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Password.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                ShowError("Please enter both username and password.");
                return;
            }

            using (var db = new ProductManagementContext())
            {
                var user = db.tblUsers
                    .FirstOrDefault(u => u.UserName == username && u.UserPassword == password);

                if (user != null)
                {
                    if (user.UserRole == "Admin")
                    {
                        AdminPage adminPage = new AdminPage();
                        adminPage.Show();
                        this.Close();
                    }
                    else if (user.UserRole == "Customer")
                    {
                        CustomerPage customerPage = new CustomerPage(user.UserName);
                        customerPage.Show();
                        this.Close();
                    }
                    else
                    {
                        ShowError("Invalid user role. Please contact the administrator.");
                    }
                }
                else
                {
                    ShowError("Invalid username or password.");
                }
            }
        }

        private void ShowError(string message)
        {
            txtStatus.Text = message;
            txtStatus.Visibility = Visibility.Visible;
        }
    }
}
