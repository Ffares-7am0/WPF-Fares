﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace ProductManagementSystem
{
    public partial class CustomerPage : Window
    {
        private ObservableCollection<tblProducts> products = new ObservableCollection<tblProducts>();
        private ObservableCollection<CartItem> cart = new ObservableCollection<CartItem>();
        private readonly string currentUsername;

        public CustomerPage(string username)
        {
            InitializeComponent();
            currentUsername = username;
            LoadProducts();
            dgCart.ItemsSource = cart;
            UpdateWelcomeText();
        }

        private void UpdateWelcomeText()
        {
            header.Text = $"Welcome, {currentUsername}!";
        }

        private void LoadProducts()
        {
            try
            {
                products.Clear();
                using (var context = new ProductManagementContext())
                {
                    foreach (var p in context.tblProducts)
                        products.Add(p);
                }
                dgProducts.ItemsSource = products;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading products: " + ex.Message);
            }
        }

        // ✅ إضافة منتج للكارت (وتقليل الكمية في قاعدة البيانات فورًا)
        private void BtnAddToCart_Click(object sender, RoutedEventArgs e)
        {
            if (dgProducts.SelectedItem is tblProducts selected)
            {
                try
                {
                    using (var context = new ProductManagementContext())
                    {
                        var product = context.tblProducts.FirstOrDefault(p => p.ProductId == selected.ProductId);
                        if (product == null || product.InStockQuantity <= 0)
                        {
                            MessageBox.Show("This product is out of stock.");
                            return;
                        }

                        // قلل الكمية في الداتابيز
                        product.InStockQuantity--;
                        context.SaveChanges();

                        // شوف لو المنتج موجود بالكارت
                        var existing = cart.FirstOrDefault(c => c.ProductId == product.ProductId);
                        if (existing != null)
                            existing.Quantity++;
                        else
                            cart.Add(new CartItem
                            {
                                ProductId = product.ProductId,
                                ProductName = product.ProductName,
                                ProductPrice = product.ProductPrice,
                                Quantity = 1
                            });

                        // لو الكمية بقت صفر، شيّله من العرض
                        if (product.InStockQuantity == 0)
                            products.Remove(selected);

                        UpdateTotal();
                        dgCart.Items.Refresh();
                        LoadProducts(); // حدّث العرض
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error adding to cart: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Select a product first.");
            }
        }

        // ✅ إزالة قطعة واحدة من الكارت (وزيادة الكمية في قاعدة البيانات)
        private void BtnRemove_Click(object sender, RoutedEventArgs e)
        {
            if (dgCart.SelectedItem is CartItem selected)
            {
                try
                {
                    using (var context = new ProductManagementContext())
                    {
                        var product = context.tblProducts.FirstOrDefault(p => p.ProductId == selected.ProductId);
                        if (product != null)
                        {
                            product.InStockQuantity++; // رجّعها للمخزون
                            context.SaveChanges();
                        }
                    }

                    selected.Quantity--;
                    if (selected.Quantity <= 0)
                        cart.Remove(selected);

                    UpdateTotal();
                    dgCart.Items.Refresh();
                    LoadProducts();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error removing from cart: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Select an item to remove.");
            }
        }

        // ✅ تحديث المجموع
        private void UpdateTotal()
        {
            decimal total = cart.Sum(c => c.ProductPrice * c.Quantity);
            txtTotal.Text = $"{total:F2} EGP";
        }

        // ✅ عند الضغط على Checkout (هنا بس بنخلي الكارت فاضي)
        private void BtnCheckout_Click(object sender, RoutedEventArgs e)
        {
            if (cart.Count == 0)
            {
                MessageBox.Show("Your cart is empty.");
                return;
            }

            MessageBox.Show("✅ Purchase successful!");
            cart.Clear();
            UpdateTotal();
            dgCart.Items.Refresh();
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            var login = new LoginPage();
            login.Show();
            this.Close();
        }
    }

    public class CartItem
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public decimal ProductPrice { get; set; }
        public int Quantity { get; set; }
    }
}
