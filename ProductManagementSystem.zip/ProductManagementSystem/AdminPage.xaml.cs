﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace ProductManagementSystem
{
    public partial class AdminPage : Window
    {
        private ObservableCollection<tblProducts> products = new ObservableCollection<tblProducts>();
        private tblProducts selectedProduct;

        public AdminPage()
        {
            InitializeComponent();
            LoadProducts();
        }

        private void LoadProducts()
        {
            try
            {
                products.Clear();
                using (var context = new ProductManagementContext())
                {
                    foreach (var p in context.tblProducts)
                        products.Add(p);
                }
                dgProducts.ItemsSource = products;
                txtStatus.Text = $"Loaded {products.Count} products.";
            }
            catch (Exception ex)
            {
                txtStatus.Text = "Error loading: " + ex.Message;
            }
        }

        private void dgProducts_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgProducts.SelectedItem is tblProducts sel)
            {
                selectedProduct = sel;
                txtNewName.Text = sel.ProductName;
                txtNewDesc.Text = sel.ProductDescription;
                txtNewQty.Text = sel.InStockQuantity.ToString();
                txtNewPrice.Text = sel.ProductPrice.ToString();
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var name = txtNewName.Text.Trim();
                var desc = txtNewDesc.Text.Trim();
                int.TryParse(txtNewQty.Text, out int qty);
                decimal.TryParse(txtNewPrice.Text, out decimal price);

                if (string.IsNullOrEmpty(name))
                {
                    txtStatus.Text = "Enter a product name.";
                    return;
                }

                var newProduct = new tblProducts
                {
                    ProductName = name,
                    ProductDescription = desc,
                    InStockQuantity = qty,
                    ProductPrice = price
                };

                using (var context = new ProductManagementContext())
                {
                    context.tblProducts.Add(newProduct);
                    context.SaveChanges();
                }

                LoadProducts();
                ClearFields();
                txtStatus.Text = "✅ Product added successfully.";
            }
            catch (Exception ex)
            {
                txtStatus.Text = "Error adding: " + ex.Message;
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (selectedProduct == null)
            {
                txtStatus.Text = "Select a product first.";
                return;
            }

            try
            {
                using (var context = new ProductManagementContext())
                {
                    var prod = context.tblProducts.FirstOrDefault(p => p.ProductId == selectedProduct.ProductId);
                    if (prod != null)
                    {
                        context.tblProducts.Remove(prod);
                        context.SaveChanges();
                    }
                }
                LoadProducts();
                ClearFields();
                txtStatus.Text = "🗑️ Product deleted.";
            }
            catch (Exception ex)
            {
                txtStatus.Text = "Error deleting: " + ex.Message;
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (selectedProduct == null)
            {
                txtStatus.Text = "Select a product to update.";
                return;
            }

            try
            {
                using (var context = new ProductManagementContext())
                {
                    var prod = context.tblProducts.FirstOrDefault(p => p.ProductId == selectedProduct.ProductId);
                    if (prod != null)
                    {
                        prod.ProductName = txtNewName.Text.Trim();
                        prod.ProductDescription = txtNewDesc.Text.Trim();
                        int.TryParse(txtNewQty.Text, out int qty);
                        decimal.TryParse(txtNewPrice.Text, out decimal price);
                        prod.InStockQuantity = qty;
                        prod.ProductPrice = price;

                        if (qty < 10)
                        {
                            MessageBox.Show("⚠️ Warning: Quantity is below 10!", "Low Stock", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }

                        context.SaveChanges();
                    }
                }

                LoadProducts();
                ClearFields();
                txtStatus.Text = "💾 All changes saved successfully.";
            }
            catch (Exception ex)
            {
                txtStatus.Text = "Error saving: " + ex.Message;
            }
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            ClearFields();
            txtStatus.Text = "Cleared all fields.";
        }

        private void ClearFields()
        {
            txtNewName.Clear();
            txtNewDesc.Clear();
            txtNewQty.Clear();
            txtNewPrice.Clear();
            selectedProduct = null;
            dgProducts.SelectedItem = null;
        }
        private void dgProducts_LoadingRow(object sender, System.Windows.Controls.DataGridRowEventArgs e)
        {
            if (e.Row.Item is tblProducts product)
            {
                if (product.InStockQuantity < 10)
                {
                    e.Row.Background = System.Windows.Media.Brushes.LightCoral;
                }
                else
                {
                    e.Row.Background = System.Windows.Media.Brushes.White;
                }
            }
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            LoginPage loginPage = new LoginPage();
            loginPage.Show();
            this.Close();
        }
    }
}
