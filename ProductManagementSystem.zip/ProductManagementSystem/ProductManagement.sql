CREATE DATABASE ProductManagementDB;
GO

USE ProductManagementDB;
GO

CREATE TABLE tblUsers (
    UserId INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(100) NOT NULL,
    UserPassword NVARCHAR(100) NOT NULL,
    UserRole NVARCHAR(20) CHECK (UserRole IN ('Admin', 'Customer')) NOT NULL
);
GO
INSERT INTO tblUsers VALUES('admin', 'admin', 'Admin')
CREATE TABLE tblProducts (
    ProductId INT IDENTITY(1,1) PRIMARY KEY,
    ProductName NVARCHAR(150) NOT NULL,
    ProductDescription NVARCHAR(255),
    InStockQuantity INT NOT NULL CHECK (InStockQuantity >= 0)
);
GO

CREATE TABLE tblCart (
    CartId INT IDENTITY(1,1) PRIMARY KEY,
    UserId INT NOT NULL REFERENCES tblUsers(UserId),
    CreatedAt DATETIME DEFAULT GETDATE(),
);
GO

CREATE TABLE tblCartItem (
    CartItemId INT IDENTITY(1,1) PRIMARY KEY,
    CartId INT NOT NULL REFERENCES tblCart(CartId),
    ProductId INT NOT NULL REFERENCES tblProducts(ProductId),
    Amount INT NOT NULL CHECK (Amount > 0),
);
GO
