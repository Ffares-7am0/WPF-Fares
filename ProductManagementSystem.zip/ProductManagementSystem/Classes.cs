﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductManagementSystem
{
    public class tblUsers
    {
        [Key]
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string UserPassword { get; set; }
        public string UserRole { get; set; }

        public ICollection<tblCart> Carts { get; set; }
    }

    public class tblProducts
    {
        [Key]
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string ProductDescription { get; set; }
        public int InStockQuantity { get; set; }
        public decimal ProductPrice { get; set; }

        public ICollection<tblCartItem> CartItems { get; set; }
    }

    public class tblCart
    {
        [Key]
        public int CartId { get; set; }
        public int UserId { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.Now;

        public tblUsers User { get; set; }
        public ICollection<tblCartItem> CartItems { get; set; }
    }

    public class tblCartItem
    {
        [Key]
        public int CartItemId { get; set; }
        public int CartId { get; set; }
        public int ProductId { get; set; }
        public int Amount { get; set; }

        public tblCart Cart { get; set; }
        public tblProducts Product { get; set; }
    }
}
