﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.EntityFrameworkCore;

namespace StudentGradebookSystem
{
    // ViewModel to bind to dgGrades (strongly typed, no dynamic)
    public class GradeViewModel
    {
        public int GradeID { get; set; }
        public string AssignmentName { get; set; }
        public string Student { get; set; }
        public decimal Score { get; set; }
        public decimal MaxScore { get; set; }
        public double Average { get; set; }
    }

    public partial class GradeManagementPage : Window
    {
        private readonly Users _teacher;
        private readonly StudentGradebookContext _context;

        public GradeManagementPage(Users teacher)
        {
            InitializeComponent();
            _teacher = teacher;
            _context = new StudentGradebookContext();

            Loaded += GradeManagementPage_Loaded;
        }

        private void GradeManagementPage_Loaded(object sender, RoutedEventArgs e)
        {
            LoadCourses();
        }

        private void LoadCourses()
        {
            try
            {
                var courses = _context.Courses
                    .Where(c => c.TeacherID == _teacher.UserID)
                    .ToList();

                cmbCourses.ItemsSource = courses;
                cmbCourses.DisplayMemberPath = "CourseName";
                cmbCourses.SelectedValuePath = "CourseID";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading courses: " + ex.Message);
            }
        }

        private void cmbCourses_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbCourses.SelectedValue == null)
                return;

            int courseId = (int)cmbCourses.SelectedValue;
            LoadStudents(courseId);
            LoadGrades(courseId);
        }

        private void LoadStudents(int courseId)
        {
            var students = _context.Enrollments
                .Include(en => en.User)
                .Where(en => en.CourseID == courseId && en.User.UserRole == "Student")
                .Select(en => new
                {
                    StudentID = en.User.UserID,
                    StudentName = en.User.Username
                })
                .ToList();

            dgStudents.ItemsSource = students;
        }

        private void LoadGrades(int courseId)
        {
            var grades = _context.Grades
                .Include(g => g.Enrollment)
                .ThenInclude(en => en.User)
                .Where(g => g.Enrollment.CourseID == courseId)
                .Select(g => new GradeViewModel
                {
                    GradeID = g.GradeID,
                    AssignmentName = g.AssignmentName,
                    Student = g.Enrollment.User.Username,
                    Score = g.Score,
                    MaxScore = g.MaxScore,
                    Average = g.MaxScore > 0 ? Math.Round((double)(g.Score / g.MaxScore) * 100, 2) : 0
                })
                .ToList();

            dgGrades.ItemsSource = grades;
        }

        private void AddGrade_Click(object sender, RoutedEventArgs e)
        {
            if (cmbCourses.SelectedValue == null)
            {
                MessageBox.Show("Select a course first.");
                return;
            }

            int courseId = (int)cmbCourses.SelectedValue;
            string assignmentName = txtAssignmentName.Text.Trim();
            string studentName = txtStudentName.Text.Trim();

            if (string.IsNullOrEmpty(assignmentName) || string.IsNullOrEmpty(studentName))
            {
                MessageBox.Show("Please fill all fields.");
                return;
            }

            var enrollment = _context.Enrollments
                .Include(en => en.User)
                .FirstOrDefault(en => en.CourseID == courseId && en.User.Username == studentName);

            if (enrollment == null)
            {
                MessageBox.Show("Student not found in this course.");
                return;
            }

            if (!decimal.TryParse(txtScore.Text, out decimal score) ||
                !decimal.TryParse(txtMaxScore.Text, out decimal maxScore))
            {
                MessageBox.Show("Invalid numeric values for score or max score.");
                return;
            }

            var grade = new Grade
            {
                EnrollmentID = enrollment.EnrollmentID,
                AssignmentName = assignmentName,
                Score = score,
                MaxScore = maxScore
            };

            _context.Grades.Add(grade);
            _context.SaveChanges();
            LoadGrades(courseId);
            ClearInputs();
        }

        private void EditGrade_Click(object sender, RoutedEventArgs e)
        {
            if (dgGrades.SelectedItem == null || cmbCourses.SelectedValue == null)
            {
                MessageBox.Show("Select a grade to edit.");
                return;
            }

            int courseId = (int)cmbCourses.SelectedValue;
            var selected = dgGrades.SelectedItem as GradeViewModel;

            if (selected == null)
            {
                MessageBox.Show("Unexpected selection type.");
                return;
            }

            var grade = _context.Grades
                .Include(g => g.Enrollment)
                .ThenInclude(en => en.User)
                .FirstOrDefault(g => g.GradeID == selected.GradeID);

            if (grade != null)
            {
                grade.AssignmentName = txtAssignmentName.Text.Trim();

                if (decimal.TryParse(txtScore.Text, out decimal score)) grade.Score = score;
                if (decimal.TryParse(txtMaxScore.Text, out decimal max)) grade.MaxScore = max;

                _context.SaveChanges();
                LoadGrades(courseId);
                ClearInputs();
            }
        }

        private void DeleteGrade_Click(object sender, RoutedEventArgs e)
        {
            if (dgGrades.SelectedItem == null || cmbCourses.SelectedValue == null)
            {
                MessageBox.Show("Select a grade to delete.");
                return;
            }

            int courseId = (int)cmbCourses.SelectedValue;
            var selected = dgGrades.SelectedItem as GradeViewModel;

            if (selected == null)
            {
                MessageBox.Show("Unexpected selection type.");
                return;
            }

            var grade = _context.Grades.FirstOrDefault(g => g.GradeID == selected.GradeID);

            if (grade != null)
            {
                _context.Grades.Remove(grade);
                _context.SaveChanges();
                LoadGrades(courseId);
                ClearInputs();
            }
        }

        private void dgGrades_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selected = dgGrades.SelectedItem as GradeViewModel;
            if (selected == null) return;

            txtAssignmentName.Text = selected.AssignmentName;
            txtStudentName.Text = selected.Student;
            txtScore.Text = selected.Score.ToString();
            txtMaxScore.Text = selected.MaxScore.ToString();
        }

        // helper to clear input fields
        private void ClearInputs()
        {
            txtAssignmentName.Text = "";
            txtStudentName.Text = "";
            txtScore.Text = "";
            txtMaxScore.Text = "";
        }
    }
}
