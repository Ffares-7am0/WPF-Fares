﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StudentGradebookSystem
{
    public class Users
    {
        [Key]
        public int UserID { get; set; }
        public string Username { get; set; }

        public string UserPassword { get; set; }
        public string Email { get; set; }

        public string UserRole { get; set; }

        public virtual ICollection<Course> Courses { get; set; }
        public virtual ICollection<Enrollment> Enrollments { get; set; }
    }

    public class Course
    {
        [Key]
        public int CourseID { get; set; }

        public string CourseName { get; set; }

        [ForeignKey("Teacher")]
        public int TeacherID { get; set; }

        public virtual Users Teacher { get; set; }

        public virtual ICollection<Enrollment> Enrollments { get; set; }
    }

    public class Enrollment
    {
        [Key]
        public int EnrollmentID { get; set; }

        [ForeignKey("User")]
        public int UserID { get; set; }

        [ForeignKey("Course")]
        public int CourseID { get; set; }

        public virtual Users User { get; set; }
        public virtual Course Course { get; set; }

        public virtual ICollection<Grade> Grades { get; set; }
    }

    public class Grade
    {
        [Key]
        public int GradeID { get; set; }

        [ForeignKey("Enrollment")]
        public int EnrollmentID { get; set; }

        public string AssignmentName { get; set; }

        public decimal Score { get; set; }
        public decimal MaxScore { get; set; }

        public virtual Enrollment Enrollment { get; set; }
    }
}
