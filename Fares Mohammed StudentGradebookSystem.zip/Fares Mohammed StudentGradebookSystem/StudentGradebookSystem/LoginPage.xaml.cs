﻿using System;
using System.Linq;
using System.Windows;

namespace StudentGradebookSystem
{
    public partial class LoginPage : Window
    {
        public LoginPage()
        {
            InitializeComponent();
        }
        StudentGradebookContext context = new StudentGradebookContext();
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Password.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                txtStatus.Text = "Please enter username and password.";
                return;
            }

            try
            {
                var user = context.Users
                    .FirstOrDefault(u => u.Username == username && u.UserPassword == password);

                if (user != null)
                {
                    txtStatus.Text = "";

                    if (user.UserRole == "Teacher")
                    {
                        GradeManagementPage teacherPage = new GradeManagementPage(user);
                        teacherPage.Show();
                        this.Close();
                    }
                    else if (user.UserRole == "Student")
                    {
                        ViewGradesPage studentPage = new ViewGradesPage(user);
                        studentPage.Show();
                        this.Close();
                    }
                    else
                    {
                        txtStatus.Text = "Invalid user role.";
                    }
                }
                else
                {
                    txtStatus.Text = "Invalid username or password.";
                }
                
            }
            catch (Exception ex)
            {
                txtStatus.Text = $"Connection error: " + ex.Message;
            }
        }
    }
}
