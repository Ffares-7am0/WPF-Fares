﻿using System;
using System.Linq;
using System.Windows;
using Microsoft.EntityFrameworkCore;

namespace StudentGradebookSystem
{
    public partial class ViewGradesPage : Window
    {
        private readonly Users _student;
        private readonly StudentGradebookContext _context;

        public ViewGradesPage(Users student)
        {
            InitializeComponent();
            _student = student;
            _context = new StudentGradebookContext();
            Loaded += ViewGradesPage_Loaded;
        }

        private void ViewGradesPage_Loaded(object sender, RoutedEventArgs e)
        {
            LoadGrades();
        }

        private void LoadGrades()
        {
            try
            {
                var grades = _context.Grades
                    .Include(g => g.Enrollment)
                    .ThenInclude(e => e.Course)
                    .Include(g => g.Enrollment.User)
                    .Where(g => g.Enrollment.UserID == _student.UserID)
                    .Select(g => new
                    {
                        CourseName = g.Enrollment.Course.CourseName,
                        AssignmentName = g.AssignmentName,
                        Score = g.Score,
                        MaxScore = g.MaxScore,
                        Average = g.MaxScore > 0 ? Math.Round((double)(g.Score / g.MaxScore) * 100, 2) : 0
                    })
                    .ToList();

                dgStudentGrades.ItemsSource = grades;

                if (grades.Any())
                {
                    double overall = grades.Average(g => g.Average);
                    txtFinalAverage.Text = $"Final Course Average: {overall:F2}%";
                }
                else
                {
                    txtFinalAverage.Text = "No grades available yet.";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading grades: " + ex.Message);
            }
        }
    }
}
