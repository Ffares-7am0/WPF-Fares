CREATE DATABASE StudentGradebookDB;
GO

USE StudentGradebookDB;
GO

CREATE TABLE Users (
    UserID INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(100) NOT NULL,
    UserPassword NVARCHAR(100) NOT NULL,
    Email NVARCHAR(100) NOT NULL UNIQUE,
    UserRole NVARCHAR(20) NOT NULL CHECK (UserRole IN ('Teacher', 'Student'))
);
GO

INSERT INTO Users (Username, UserPassword, Email, UserRole)
VALUES 
('MrAhmed', '1234', 'ahmed@school.com', 'Teacher'),
('MsSalma', '1234', 'salma@school.com', 'Teacher'),
('OmarAli', '1234', 'omar@student.com', 'Student'),
('NourHassan', '1234', 'nour@student.com', 'Student'),
('SaraTarek', '1234', 'sara@student.com', 'Student');
GO

CREATE TABLE Courses (
    CourseID INT IDENTITY(1,1) PRIMARY KEY,
    CourseName NVARCHAR(100) NOT NULL,
    TeacherID INT NOT NULL,
    FOREIGN KEY (TeacherID) REFERENCES Users(UserID) ON DELETE CASCADE
);
GO

INSERT INTO Courses (CourseName, TeacherID)
VALUES
('Mathematics', 1),
('Science', 2);
GO

CREATE TABLE Enrollments (
    EnrollmentID INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT NOT NULL,
    CourseID INT NOT NULL,
    FOREIGN KEY (UserID) REFERENCES Users(UserID) ON DELETE NO ACTION,
    FOREIGN KEY (CourseID) REFERENCES Courses(CourseID) ON DELETE NO ACTION
);
GO

INSERT INTO Enrollments (UserID, CourseID)
VALUES
(3, 1),
(4, 1),
(5, 2);
GO

CREATE TABLE Grades (
    GradeID INT IDENTITY(1,1) PRIMARY KEY,
    EnrollmentID INT NOT NULL,
    AssignmentName NVARCHAR(100) NOT NULL,
    Score DECIMAL(5,2),
    MaxScore DECIMAL(5,2),
    FOREIGN KEY (EnrollmentID) REFERENCES Enrollments(EnrollmentID) ON DELETE NO ACTION
);
GO

INSERT INTO Grades (EnrollmentID, AssignmentName, Score, MaxScore)
VALUES
(1, 'Quiz 1', 8.5, 10),
(1, 'Project', 18, 20),
(2, 'Quiz 1', 7, 10),
(3, 'Lab Work', 16, 20);
GO